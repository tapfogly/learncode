-- This is a Robokit Logic file

-- if rbkConfig.simulation then
--     -- simulation
-- else
-- 	-- real
-- 	gChassis.bindEvent("emc_pressed", function ()
-- 		gMoveFactory.cancelTask()
-- 		gTask.cancel()
--     end)

--     gChassis.bindEvent("emc_released", function ()
-- 		--gMoveFactory.resumeTask(true)
-- 		--gTask.resume()
--     end)
-- end

-- gDebug.bindEvent("get_map", function()
-- 	gMap.sendMapImmediately()
-- end)

-- gDebug.bindEvent("reloc", function(x, y)
-- 	gLoc.relocService(x, y, 3, 0, 180)
-- end)

-- 地图加载完成
gLoc.bindEvent("relocFinished", function()
	gNetProtocol.setLoadmapStatus(1)
	gCalib.setRelocStatus(true)
end)

gLoc.bindEvent("relocStarted", function ()
	gNetProtocol.setRelocStatus(2)
end)

-- 重定位完成
gLoc.bindEvent("relocSuccessed", function ()
	gNetProtocol.setRelocStatus(3) -- 这里只会标记为重定位完成, 需要等用户确认成功
end)

-- 重定位失败
gLoc.bindEvent("relocFailed", function ()
	gNetProtocol.setRelocStatus(3)
end)

gNetProtocol.bindDelegate("manual", function ()
	gMoveFactory.setAutoMode(false)
	gNetProtocol.connect(gMoveFactory, "rbk.protocol.Message_ManualSpeed")
end)

gNetProtocol.bindDelegate("auto", function ()
	gMoveFactory.setAutoMode(true)
	gNetProtocol.disconnect(gMoveFactory, "rbk.protocol.Message_ManualSpeed")
end)

-- gNetProtocol.bindDelegate("afd_lift", function(position)
-- 	return gChassis.setAfdLift(position)
-- end)

-- gMoveFactory.bindEvent("isBlocked", function()
-- 	gPlayer.play("alarm.wav", true)
-- end)

-- gMoveFactory.bindEvent("isNotBlocked", function()
-- 	gPlayer.stop()
-- end)

---------- 以上内容,禁止修改 ----------
