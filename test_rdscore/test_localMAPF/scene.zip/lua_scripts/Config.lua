gConnection = "FullFeature"

gConnectionTable = {
	"FullFeature"
}

gLogic = "Common"

gLogicTable = {
	"Common"
}
