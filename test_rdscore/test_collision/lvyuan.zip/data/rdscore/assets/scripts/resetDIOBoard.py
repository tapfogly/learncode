import socket
import struct
import time
import sys

F4kCommandPort = 15003
F4kAddr = ('192.168.192.4', F4kCommandPort)
PACK_HEAD = 0x0000101E


so = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
so.settimeout(0.03)
param = 0xffffffff
msg = struct.pack('<II', PACK_HEAD, param)
so.sendto(msg, F4kAddr)
so.close()

time.sleep(1)

sys.exit(0)



