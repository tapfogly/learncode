local connectionName = "./lua_scripts/connection/"..gConnection..".lua"
dofile(connectionName)
