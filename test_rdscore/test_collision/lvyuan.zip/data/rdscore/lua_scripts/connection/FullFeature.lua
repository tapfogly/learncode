-- This is a Robokit Connection file

-- gNetProtocol = rbk.getPlugin("NetProtocol")
gRDSDispatcher= rbk.getPlugin("RDSDispatcher")
gRDSOrderAdapter = rbk.getPlugin("RDSOrderAdapter")
gRDSRobotAdapter = rbk.getPlugin("RDSRobotAdapter")
gModbusSlave = rbk.getPlugin("RDSModbusSlave")
gRDSProxy = rbk.getPlugin("RDSProxy")
-- gMapParser = rbk.getPlugin("MapParser")
gSim = rbk.getPlugin("RDSSimRobot")
gSimLift = rbk.getPlugin("RDSSimLift")


rbk.initModel()

gRDSRobotAdapter.connect(gRDSOrderAdapter, "rbk.protocol.rds.Message_RobotsStatus")
gRDSRobotAdapter.connect(gRDSDispatcher, "rbk.protocol.rds.Message_RobotsStatus")
gRDSDispatcher.connect(gRDSRobotAdapter, "rbk.protocol.rds.Message_RDSCMD")
gRDSOrderAdapter.connect(gRDSRobotAdapter, "rbk.protocol.rds.Message_RDSCMD")
gRDSDispatcher.connect(gRDSOrderAdapter, "rbk.protocol.rds.Message_OrderStatus")
gRDSDispatcher.connect(gRDSOrderAdapter, "rbk.protocol.rds.Message_DispatcherStatus")
gRDSDispatcher.connect(gModbusSlave, "rbk.protocol.rds.Message_BlockGroupStatusList")
-- gRDSDispatcher.connect(gRDSOrderAdapter, "rbk.protocol.rds.Message_BlockGroupStatusList")

gSim.connect(gRDSRobotAdapter, "rbk.protocol.rds.Message_RobotsStatus")
gRDSDispatcher.connect(gSim, "rbk.protocol.rds.Message_RDSCMD")


gRDSProxy.connect(gRDSOrderAdapter, "rbk.protocol.rds.Message_LiftsStatus")
gRDSProxy.connect(gRDSDispatcher, "rbk.protocol.rds.Message_LiftsStatus")
gRDSProxy.connect(gRDSOrderAdapter, "rbk.protocol.rds.Message_DoorsStatus")
gRDSProxy.connect(gRDSDispatcher, "rbk.protocol.rds.Message_DoorsStatus")
gRDSProxy.connect(gRDSOrderAdapter, "rbk.protocol.rds.Message_TerminalsStatus")
gRDSProxy.connect(gRDSDispatcher, "rbk.protocol.rds.Message_TerminalsStatus")

gSimLift.connect(gRDSDispatcher, "rbk.protocol.rds.Message_LiftsStatus")
gSimLift.connect(gRDSOrderAdapter, "rbk.protocol.rds.Message_LiftsStatus")

-- gMapParser.start()
gRDSDispatcher.start()
gRDSOrderAdapter.start()
gRDSRobotAdapter.start()

gModbusSlave.start()
gRDSProxy.start()

gSim.start()
gSimLift.start()


rbk.sleep(2000)
-- if rbkConfig.useNetProtocol then
-- gNetProtocol.start()
-- end


---------- 以上内容,禁止修改 ----------
